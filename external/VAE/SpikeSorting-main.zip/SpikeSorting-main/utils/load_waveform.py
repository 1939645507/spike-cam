# T. S. Liang @ HKU EEE, Jan. 23rd 2026
# Email: sliang57@connect.hku.hk
# Preprocessing of the data from achilles.

import torch
import numpy as np

data = np.load('../data/Achilles_10252013_Shank1_dataset_v2.npz')

arrays = [
    data['main_channel_waveform'],
    data['label'],
    data['spike_time'],
    data['channel_max'],
    data['channel_min'],
    data['main_channel_index']
]

processed_list = []
total_samples = len(arrays[0])
print("Processing samples...")

for i in range(total_samples):
    sample = {
        'waveform': torch.tensor(arrays[0][i], dtype=torch.float32),
        'label': torch.tensor(arrays[1][i], dtype=torch.float32),
        'spike_time': torch.tensor(arrays[2][i], dtype=torch.float32),
        'channel_max': torch.tensor(arrays[3][i], dtype=torch.float32),
        'channel_min': torch.tensor(arrays[4][i], dtype=torch.float32),
        'main_channel_index': torch.tensor(arrays[5][i], dtype=torch.float32)
    }
    processed_list.append(sample)


# Spliting the validation set and the training set.
seed = 42
generator = torch.Generator().manual_seed(seed)
indices = torch.randperm(total_samples, generator=generator).tolist()

split_idx = int(total_samples * 0.8)

train_indices = indices[:split_idx]
val_indices = indices[split_idx:]

train_set = [processed_list[i] for i in train_indices]
val_set = [processed_list[i] for i in val_indices]

train_output_path = '../data/Achilles_Shank1_train.pt'
val_output_path = '../data/Achilles_Shank1_val.pt'

torch.save(train_set, train_output_path)
torch.save(val_set, val_output_path)

print("-" * 30)
print(f"✅ Split completed with seed {seed}")
print(f"   Train set size: {len(train_set)} (Saved to: {train_output_path})")
print(f"   Val set size:   {len(val_set)}   (Saved to: {val_output_path})")